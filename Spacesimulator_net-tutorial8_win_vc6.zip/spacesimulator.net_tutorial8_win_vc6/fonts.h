#ifndef _FONTS_H
#define _FONTS_H

#include "mat_vect.h"
#include "mat_matr.h"

#define MAX_FONTS 10 // Max number of fonts

typedef struct{
    
    int list_base; //Base number of the OpenGL list that contain the font
	int texture_id; //Texture ID of the font

}font_type;

extern font_type font[MAX_FONTS];
extern char FontCreate(char *p_file_name,int p_grid_x_qty,int p_grid_y_qty,int p_fonts_start_pos,int p_fonts_end_pos,int p_ascii_offset,int p_fonts_spacing);
extern void FontPrint(int p_font, int p_x, int p_y, char *p_string);

#endif
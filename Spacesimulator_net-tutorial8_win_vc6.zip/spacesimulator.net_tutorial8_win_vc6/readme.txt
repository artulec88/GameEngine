---------------- www.spacesimulator.net --------------
  ---- Space simulators and 3d engine tutorials ----

Author: Damiano Vitulli

This program is released under the BSD licence
By using this program you agree to licence terms on spacesimulator.net copyright page

----------------
List of commands
----------------

Arrow keys: Rotate the active object around x,z axis
k,l: Rotate the active object around y axis
j,m: Translate the active object around its z axis
page UP, page DOWN: make active the next object

w,s: Translate the camera around its z axis
e,c: Rotate the camera around its x axis
a,d: Rotate the camera around its y axis
z,x: Rotate the camera around its z axis

ESC: Exit the program (under WinXP the only safely way =( )

----------------
Known bugs
----------------

Under WinXP if you close the window, using the 
controlbox close button, the program continue to run
in background, you can see it on the task manager.
The only way to close safely the program under WinXP is pressing ESC!
This is a Glut problem, I had not success to solve it.
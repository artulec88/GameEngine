#pragma once

#include "Math.h"
#include "Vector.h"

namespace Math
{

template<typename T, unsigned int D>
class Matrix
{
public:
	inline Matrix<T, D>& InitIdentity();
	
	inline Matrix<T, D>& InitScale(const Vector<T,D - 1>& r);
	
	inline Matrix<T, D>& InitTranslation(const Vector<T,D - 1>& r);

	inline Matrix<T, D> Transpose() const;

// This function doesn't appear to work!
	inline Matrix<T, D> Inverse() const;

	inline Matrix<T,D> operator*(const Matrix<T,D>& r) const;
	
	inline Vector<T,D> Transform(const Vector<T,D>& r) const;
	
	inline Vector<T,D-1> Transform(const Vector<T,D-1>& r) const;
	
	inline void Set(unsigned int x, unsigned int y, T val);
	
	inline const T* operator[](int index) const;
	inline T* operator[](int index);
protected:
private:
	T m[D][D];
};

template<typename T>
class Matrix4 : public Matrix<T, 4>
{
public:
	Matrix4();

	template<unsigned int D>
	Matrix4(const Matrix<T, D>& r);

	Matrix4<T>& InitRotationEuler(T rotateX, T rotateY, T rotateZ);
	
	Matrix4<T>& InitRotationFromVectors(const Vector3<T>& n, const Vector3<T>& v, const Vector3<T>& u);
	
	Matrix4<T>& InitRotationFromDirection(const Vector3<T>& forward, const Vector3<T>& up);
	
	Matrix4<T>& InitPerspective(T fov, T aspectRatio, T zNear, T zFar);
	
	Matrix4<T>& InitOrthographic(T left, T right, T bottom, T top, T near, T far);
protected:
private:
};

template<typename T>
class Matrix3 : public Matrix<T, 3>
{
public:
	Matrix3();
	
	template<unsigned int D>
	Matrix3(const Matrix<T, D>& r);
};

typedef Matrix<int, 2> Matrix2i;
typedef Matrix3<int> Matrix3i;
typedef Matrix4<int> Matrix4i;

typedef Matrix<float, 2> Matrix2f;
typedef Matrix3<float> Matrix3f;
typedef Matrix4<float> Matrix4f;

//typedef Matrix<double, 2> Matrix2d;
//typedef Matrix3<double> Matrix3d;
//typedef Matrix4<double> Matrix4d;

}
#pragma once

#include <math.h>
#include "Math.h"

namespace Math
{
	template<typename T, unsigned int D>
	class Vector
	{
	public:
		Vector();
		Vector(T* valuesArray);

		inline T Dot(const Vector<T, D>& r) const;
		
		inline T Max() const;
		
		inline T LengthSq() const;
		inline T Length() const;
		inline Vector<T,D> Normalized() const;
		inline Vector<T,D> Lerp(const Vector<T,D>& r, T lerpFactor) const;

		inline Vector<T, D> operator+(const Vector<T,D>& r) const;		
		inline Vector<T, D> operator-(const Vector<T,D>& r) const;
		inline Vector<T, D> operator*(const T& r) const;		
		inline Vector<T, D> operator/(const T& r) const;
		inline Vector<T, D>& operator+=(const Vector<T,D>& r);		
		inline Vector<T, D>& operator-=(const Vector<T,D>& r);		
		inline Vector<T, D>& operator*=(const T& r);		
		inline Vector<T, D>& operator/=(const T& r);

		T& operator [] (unsigned int i);
		T operator [] (unsigned int i) const;
		
		inline bool operator==(const Vector<T,D>& r) const;		
		inline bool operator!=(const Vector<T,D>& r) const;
	private:
		T values[D];
	};

	template<typename T>
	class Vector2 : public Vector<T, 2>
	{
	public:
		Vector2();
		Vector2(const Vector<T, 2>& r);
		Vector2(T x, T y);
		
		T Cross(const Vector2<T>& r) const;
		
		inline T GetX() const;
		inline T GetY() const;
		
		inline void SetX(const T& x);
		inline void SetY(const T& y);
		
		inline void Set(const T& x, const T& y);
	protected:
	private:
	};

	template<typename T>
	class Vector3 : public Vector<T, 3>
	{
	public:
		Vector3();
		
		Vector3(const Vector<T, 3>& r);
		
		Vector3(T x, T y, T z);
		
		inline Vector3<T> Cross(const Vector3<T>& r) const;
		
		inline Vector3<T> Rotate(T angle, const Vector3<T>& axis) const;
		
		inline Vector2<T> GetXY() const;
		inline Vector2<T> GetYZ() const;
		inline Vector2<T> GetZX() const;
		
		inline Vector2<T> GetYX() const;
		inline Vector2<T> GetZY() const;
		inline Vector2<T> GetXZ() const;
		
		inline T GetX() const;
		inline T GetY() const;
		inline T GetZ() const;
		
		inline void SetX(const T& x);
		inline void SetY(const T& y);
		inline void SetZ(const T& z);
		
		inline void Set(const T& x, const T& y, const T& z);
	protected:
	private:
	};

	template<typename T>
	class Vector4 : public Vector<T, 4>
	{
	public:
		Vector4();
		
		Vector4(const Vector<T, 4>& r);
		
	//	Vector4(const Vector<T, 3>& r);
		
		Vector4(T x, T y, T z, T w);
		
		inline T GetX() const;
		inline T GetY() const;
		inline T GetZ() const;
		inline T GetW() const;
		
		inline void SetX(const T& x);
		inline void SetY(const T& y);
		inline void SetZ(const T& z);
		inline void SetW(const T& w);
		
		inline void Set(const T& x, const T& y, const T& z, const T& w);
	protected:
	private:
	};

	class Quaternion;

	class MATH_API Vector3f : public Vector3<float>
	{
	public:
		Vector3f(float x = 0.0f, float y = 0.0f, float z = 0.0f);
		
		Vector3f(const Vector3<float>& r);

		inline float Length() const;
		inline float Dot(const Vector3f& v) const;

		inline Vector3f Cross(const Vector3f& v) const;

		inline Vector3f Rotate(float angle, const Vector3f& axis) const;

		Vector3f Rotate(const Quaternion& rotation) const;

		inline Vector3f Normalized() const;

		inline Vector3f operator+(const Vector3f& r) const;
		inline Vector3f operator-(const Vector3f& r) const;
		inline Vector3f operator*(float f) const;
		inline Vector3f operator/(float f) const;

		inline bool operator==(const Vector3f& r) const;
		inline bool operator!=(const Vector3f& r) const;

		inline Vector3f& operator+=(const Vector3f& r);
		inline Vector3f& operator-=(const Vector3f& r);	    
		inline Vector3f& operator*=(float f);	    
		inline Vector3f& operator/=(float f);

		inline float GetX() const;
		inline float GetY() const;
		inline float GetZ() const;

		inline void SetX(float x);
		inline void SetY(float y);
		inline void SetZ(float z);

		inline void Set(float x, float y, float z);
	private:
		//float x,y,z;
	};

	typedef Vector2<int> Vector2i;
	typedef Vector3<int> Vector3i;
	typedef Vector4<int> Vector4i;

	typedef Vector2<float> Vector2f;
	//typedef Vector3<float> Vector3f;
	typedef Vector4<float> Vector4f;

	//typedef Vector2<double> Vector2d;
	//typedef Vector3<double> Vector3d;
	//typedef Vector4<double> Vector4d;
}
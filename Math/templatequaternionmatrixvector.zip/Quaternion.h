#pragma once

#include "Math.h"
#include "Vector.h"
#include "Matrix.h"

namespace Math
{

class MATH_API Quaternion : public Vector4<float>
{
public:
	Quaternion(float x = 0.0f, float y = 0.0f, float z = 0.0f, float w = 1.0f);
	Quaternion(const Vector4<float>& r);
	Quaternion(const Vector3f& axis, float angle);
	Quaternion(const Matrix4f& m);
	
	inline Quaternion NLerp(const Quaternion& r, float lerpFactor, bool shortestPath) const;
	inline Quaternion SLerp(const Quaternion& r, float lerpFactor, bool shortestPath) const;
	
	inline Matrix4f ToRotationMatrix() const;
	
	inline Vector3f GetForward() const;
	inline Vector3f GetBack() const;
	inline Vector3f GetUp() const;
	inline Vector3f GetDown() const;
	inline Vector3f GetRight() const;
	inline Vector3f GetLeft() const;

	inline Quaternion Conjugate() const;
	inline Quaternion operator*(const Quaternion& r) const;
	inline Quaternion operator*(const Vector3<float>& v) const;
};

}
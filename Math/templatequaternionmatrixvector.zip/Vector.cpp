#include "stdafx.h"
#include "Vector.h"
#include "Quaternion.h"

using namespace Math;

template<typename T, unsigned int D>
Vector<T,D>::Vector() { };

template<typename T, unsigned int D>
Vector<T,D>::Vector(T* valuesArray)
{
	for (unsigned int i = 0; i < D; ++i)
	{
		(*this)[i] = valuesArray[i];
	}
}

template<typename T, unsigned int D>
inline T Vector<T,D>::Dot(const Vector<T, D>& r) const
{
	T result = T(0);
	for(unsigned int i = 0; i < D; i++)
		result += (*this)[i] * r[i];
		
	return result;
}

template<typename T, unsigned int D>
inline T Vector<T,D>::Max() const
{
	T Max = (*this)[0];
	
	for(int i = 0; i < D; i++)
		if((*this)[i] > Max)
			Max = (*this)[i];
	
	return Max;
}

template<typename T, unsigned int D>
inline T Vector<T,D>::LengthSq() const { return this->Dot(*this); }

template<typename T, unsigned int D>
inline T Vector<T,D>::Length() const { return static_cast<T>(sqrt(static_cast<float>(LengthSq()))); /*static_cast<float>(sqrt(static_cast<float>(LengthSq())));*/ }

template<typename T, unsigned int D>
inline Vector<T,D> Vector<T,D>::Normalized() const { return *this/Length(); }

template<typename T, unsigned int D>
inline Vector<T,D> Vector<T,D>::Lerp(const Vector<T,D>& r, T lerpFactor) const { return (r - *this) * lerpFactor + *this; }

template<typename T, unsigned int D>
inline Vector<T, D> Vector<T,D>::operator+(const Vector<T,D>& r) const
{
	Vector<T, D> result;
	for(unsigned int i = 0; i < D; i++)
		result[i] = values[i] + r[i];
	
	return result;
}

template<typename T, unsigned int D>
inline Vector<T, D> Vector<T,D>::operator-(const Vector<T,D>& r) const
{
	Vector<T, D> result;
	for(unsigned int i = 0; i < D; i++)
		result[i] = values[i] - r[i];
	
	return result;
}

template<typename T, unsigned int D>
inline Vector<T, D> Vector<T,D>::operator*(const T& r) const
{
	Vector<T, D> result;
	for(unsigned int i = 0; i < D; i++)
		result[i] = values[i] * r;
	
	return result;
}

template<typename T, unsigned int D>
inline Vector<T, D> Vector<T,D>::operator/(const T& r) const
{
	Vector<T, D> result;
	for(unsigned int i = 0; i < D; i++)
		result[i] = values[i] / r;
	
	return result;
}

template<typename T, unsigned int D>
inline Vector<T, D>& Vector<T,D>::operator+=(const Vector<T,D>& r) 
{
	for(unsigned int i = 0; i < D; i++)
		(*this)[i] = values[i] + r[i];
	
	return *this;
}

template<typename T, unsigned int D>
inline Vector<T, D>& Vector<T,D>::operator-=(const Vector<T,D>& r) 
{
	for(unsigned int i = 0; i < D; i++)
		(*this)[i] = values[i] - r[i];
	
	return *this;
}

template<typename T, unsigned int D>
inline Vector<T, D>& Vector<T,D>::operator*=(const T& r) 
{
	for(unsigned int i = 0; i < D; i++)
		(*this)[i] = values[i] * r;
	
	return *this;
}

template<typename T, unsigned int D>
inline Vector<T, D>& Vector<T,D>::operator/=(const T& r) 
{
	for(unsigned int i = 0; i < D; i++)
		(*this)[i] = values[i] / r;
	
	return *this;
}

template<typename T, unsigned int D>
T& Vector<T,D>::operator [] (unsigned int i) { return values[i]; }

template<typename T, unsigned int D>
T Vector<T,D>::operator [] (unsigned int i) const { return values[i]; }

template<typename T, unsigned int D>
inline bool Vector<T,D>::operator==(const Vector<T,D>& r) const
{
	for(unsigned int i = 0; i < D; i++)
		if((*this)[i] != r[i])
			return false;
	return true;
}

template<typename T, unsigned int D>
inline bool Vector<T,D>::operator!=(const Vector<T,D>& r) const { return !operator==(r); }

template<typename T>
Vector2<T>::Vector2() { }
		
template<typename T>
Vector2<T>::Vector2(const Vector<T, 2>& r)
{
	(*this)[0] = r[0];
	(*this)[1] = r[1];
}
		
template<typename T>
Vector2<T>::Vector2(T x, T y)
{
	(*this)[0] = x;
	(*this)[1] = y;
}
template<typename T>		
T Vector2<T>::Cross(const Vector2<T>& r) const
{
	return GetX() * r.GetY() - GetY() * r.GetX();
}

template<typename T>
inline T Vector2<T>::GetX() const { return (*this)[0]; }

template<typename T>
inline T Vector2<T>::GetY() const { return (*this)[1]; }

template<typename T>
inline void Vector2<T>::SetX(const T& x) { (*this)[0] = x; }

template<typename T>
inline void Vector2<T>::SetY(const T& y) { (*this)[1] = y; }

template<typename T>
inline void Vector2<T>::Set(const T& x, const T& y) { SetX(x); SetY(y); }

template<typename T>
Vector3<T>::Vector3() { }

template<typename T>
Vector3<T>::Vector3(const Vector<T, 3>& r)
{
	(*this)[0] = r[0];
	(*this)[1] = r[1];
	(*this)[2] = r[2];
}

template<typename T>
Vector3<T>::Vector3(T x, T y, T z)
{
	(*this)[0] = x;
	(*this)[1] = y;
	(*this)[2] = z;
}

template<typename T>
inline Vector3<T> Vector3<T>::Cross(const Vector3<T>& r) const
{
	T x = (*this)[1] * r[2] - (*this)[2] * r[1];
	T y = (*this)[2] * r[0] - (*this)[0] * r[2];
	T z = (*this)[0] * r[1] - (*this)[1] * r[0];

	return Vector3<T>(x, y, z);
}

template<typename T>
inline Vector3<T> Vector3<T>::Rotate(T angle, const Vector3<T>& axis) const
{
	const T sinAngle = sin(-static_cast<float>(angle));
	const T cosAngle = cos(-static_cast<float>(angle));
	
	return this->Cross(axis * sinAngle) +        //Rotation on local X
		(*this * cosAngle) +                     //Rotation on local Z
		axis * this->Dot(axis * (1 - cosAngle)); //Rotation on local Y
}

template<typename T>
inline Vector2<T> Vector3<T>::GetXY() const { return Vector2<T>(GetX(), GetY()); }
template<typename T>
inline Vector2<T> Vector3<T>::GetYZ() const { return Vector2<T>(GetY(), GetZ()); }
template<typename T>
inline Vector2<T> Vector3<T>::GetZX() const { return Vector2<T>(GetZ(), GetX()); }

template<typename T>
inline Vector2<T> Vector3<T>::GetYX() const { return Vector2<T>(GetY(), GetX()); }
template<typename T>
inline Vector2<T> Vector3<T>::GetZY() const { return Vector2<T>(GetZ(), GetY()); }
template<typename T>
inline Vector2<T> Vector3<T>::GetXZ() const { return Vector2<T>(GetX(), GetZ()); }

template<typename T>
inline T Vector3<T>::GetX() const { return (*this)[0]; }
template<typename T>
inline T Vector3<T>::GetY() const { return (*this)[1]; }
template<typename T>
inline T Vector3<T>::GetZ() const { return (*this)[2]; }

template<typename T>
inline void Vector3<T>::SetX(const T& x) { (*this)[0] = x; }
template<typename T>
inline void Vector3<T>::SetY(const T& y) { (*this)[1] = y; }
template<typename T>
inline void Vector3<T>::SetZ(const T& z) { (*this)[2] = z; }

template<typename T>
inline void Vector3<T>::Set(const T& x, const T& y, const T& z) { SetX(x); SetY(y); SetZ(z); }

template<typename T>
Vector4<T>::Vector4() { }

template<typename T>
Vector4<T>::Vector4(const Vector<T, 4>& r)
{
	(*this)[0] = r[0];
	(*this)[1] = r[1];
	(*this)[2] = r[2];
	(*this)[3] = r[3];
}

//template<typename T>
//Vector4<T>::Vector4(const Vector<T, 3>& r)
//{
//	(*this)[0] = r[0];
//	(*this)[1] = r[1];
//	(*this)[2] = r[2];
//	(*this)[3] = T(1);
//}

template<typename T>
Vector4<T>::Vector4(T x, T y, T z, T w)
{
	(*this)[0] = x;
	(*this)[1] = y;
	(*this)[2] = z;
	(*this)[3] = w;
}

template<typename T>
inline T Vector4<T>::GetX() const { return (*this)[0]; }
template<typename T>
inline T Vector4<T>::GetY() const { return (*this)[1]; }
template<typename T>
inline T Vector4<T>::GetZ() const { return (*this)[2]; }
template<typename T>
inline T Vector4<T>::GetW() const { return (*this)[3]; }

template<typename T>
inline void Vector4<T>::SetX(const T& x) { (*this)[0] = x; }
template<typename T>
inline void Vector4<T>::SetY(const T& y) { (*this)[1] = y; }
template<typename T>
inline void Vector4<T>::SetZ(const T& z) { (*this)[2] = z; }
template<typename T>
inline void Vector4<T>::SetW(const T& w) { (*this)[3] = w; }

template<typename T>
inline void Vector4<T>::Set(const T& x, const T& y, const T& z, const T& w) { SetX(x); SetY(y); SetZ(z); SetW(w); }


Vector3f::Vector3f(float x /* = 0.0f */, float y /* = 0.0f */, float z /* = 0.0f */)
{
	(*this)[0] = x;
	(*this)[1] = y;
	(*this)[2] = z;
}

Vector3f::Vector3f(const Vector3<float>& r)
{
	(*this)[0] = r[0];
	(*this)[1] = r[1];
	(*this)[2] = r[2];
}

inline float Vector3f::Length() const { return sqrtf(GetX() * GetX() + GetY() * GetY() + GetZ() * GetZ()); }
inline float Vector3f::Dot(const Vector3f& v) const { return GetX() * v.GetX() + GetY() * v.GetY() + GetZ() * v.GetZ(); }

inline Vector3f Vector3f::Cross(const Vector3f& v) const
{
	const float _x = GetY() * v.GetZ() - GetZ() * v.GetY();
	const float _y = GetZ() * v.GetX() - GetX() * v.GetZ();
	const float _z = GetX() * v.GetY() - GetY() * v.GetX();

	return Vector3f(_x, _y, _z);
}

inline Vector3f Vector3f::Rotate(float angle, const Vector3f& axis) const
{
	const float sin = sinf(-angle);
	const float cos = cosf(-angle);

	return this->Cross(axis * sin) +        //Rotation on local X
		(*this * cos) +                     //Rotation on local Z
		axis * this->Dot(axis * (1 - cos)); //Rotation on local Y

//		const float sinHalfAngle = sinf(angle/2);
//		const float cosHalfAngle = cosf(angle/2);
//
//		const float Rx = axis.x * sinHalfAngle;
//		const float Ry = axis.y * sinHalfAngle;
//		const float Rz = axis.z * sinHalfAngle;
//		const float Rw = cosHalfAngle;
//
//		Quaternion rotationQ(Rx, Ry, Rz, Rw);
//
//		Quaternion conjugateQ = rotationQ.Conjugate();
//	  //  ConjugateQ.Normalize();
//		Quaternion w = rotationQ * (*this) * conjugateQ;
//
//		Vector3f ret(w.GetX(), w.GetY(), w.GetZ());
//
//		return ret;
}

Vector3f Vector3f::Rotate(const Quaternion& rotation) const
{
	Quaternion conjugateQ = rotation.Conjugate();
	Quaternion w = rotation * (*this) * conjugateQ;

	Vector3f ret(w.GetX(), w.GetY(), w.GetZ());

	return ret;
}

inline Vector3f Vector3f::Normalized() const
{
	const float length = Length();

	return Vector3f(GetX() / length, GetY() / length, GetZ() / length);
}

inline Vector3f Vector3f::operator+(const Vector3f& r) const { return Vector3f(GetX() + r.GetX(), GetY() + r.GetY(), GetZ() + r.GetZ()); }
inline Vector3f Vector3f::operator-(const Vector3f& r) const { return Vector3f(GetX() - r.GetX(), GetY() - r.GetY(), GetZ() - r.GetZ()); }
inline Vector3f Vector3f::operator*(float f) const { return Vector3f(GetX() * f, GetY() * f, GetZ() * f); }
inline Vector3f Vector3f::operator/(float f) const { return Vector3f(GetX() / f, GetY() / f, GetZ() / f); }

inline bool Vector3f::operator==(const Vector3f& r) const { return GetX() == r.GetX() && GetY() == r.GetY() && GetZ() == r.GetZ(); }
inline bool Vector3f::operator!=(const Vector3f& r) const { return !operator==(r); }

inline Vector3f& Vector3f::operator+=(const Vector3f& r)
{
	(*this)[0] += r.GetX();
	(*this)[1] += r.GetY();
	(*this)[2] += r.GetZ();

	return *this;
}

inline Vector3f& Vector3f::operator-=(const Vector3f& r)
{
	(*this)[0] -= r.GetX();
	(*this)[1] -= r.GetY();
	(*this)[2] -= r.GetZ();

	return *this;
}

inline Vector3f& Vector3f::operator*=(float f)
{
	(*this)[0] *= f;
	(*this)[1] *= f;
	(*this)[2] *= f;

	return *this;
}

inline Vector3f& Vector3f::operator/=(float f)
{
	(*this)[0] /= f;
	(*this)[1] /= f;
	(*this)[2] /= f;

	return *this;
}

inline float Vector3f::GetX() const { return (*this)[0]; }
inline float Vector3f::GetY() const { return (*this)[1]; }
inline float Vector3f::GetZ() const { return (*this)[2]; }

inline void Vector3f::SetX(float x) { (*this)[0] = x; }
inline void Vector3f::SetY(float y) { (*this)[1] = y; }
inline void Vector3f::SetZ(float z) { (*this)[2] = z; }

inline void Vector3f::Set(float x, float y, float z) { (*this)[0] = x; (*this)[1] = y; (*this)[2] = z; }

template class Vector<int, 1>;
template class MATH_API Vector<int, 2>;
template class MATH_API Vector3<int>;
template class MATH_API Vector<int, 4>;
template class Vector<float, 1>;
template class MATH_API Vector<float, 2>;
//template class MATH_API Vector<float, 3>;
template class MATH_API Vector<float, 4>;